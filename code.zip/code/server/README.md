# Running the EzWh Server

- Open a terminal
- Open the code/server folder
- Input ```npm install```
- Input ```node server.js```
- This message will be shown: Server listening at http://localhost:3001
- Do not close the terminal window, otherwise the server will be shut down
